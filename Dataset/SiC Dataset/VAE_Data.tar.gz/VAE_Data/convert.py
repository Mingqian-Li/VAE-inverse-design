import numpy as np

lattice=np.genfromtxt('300K_Structures/POSCAR_100000',skip_header=2,max_rows=3)

sites=np.genfromtxt('300K_Structures/POSCAR_100000',skip_header=8,usecols = (0, 1,2))

#convert direct coordinates to cartesian coordinates
cartSites=np.dot(sites,lattice)

#Some of the atoms can fall outside the unit cell(negative value)
#Because of periodic boundary condition, an atom at outside the unit can be
#shifted by the lattice vector and still be the same atom.
#All I do here is shift any atoms that fall outside the unit cell back
#into the unit cell
Shift=np.dot((cartSites<0),lattice)

ShiftedcartSites=cartSites+Shift

with open('temp','w') as f:
    f.write('C Si\n')
    f.write('1.0000000000000000\n')
    for i in lattice:
        f.write('{:10.16f}    {:10.16f}    {:10.16f}\n'.format(*i))
    f.write('32 32\n')
    f.write('Cartesian\n')
    for i in ShiftedcartSites:
        f.write(' {:10.16f} {:10.16f} {:10.16f}\n'.format(*i))
        
